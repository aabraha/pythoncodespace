# 
# Example file for working with conditional statements


x, y = 100, 100

# conditional flow uses if, elif, else
# if x < y:
#   print("x is less than y") # all statements followed the colon should indent same
# elif x == y:
#   print("x is equal to y")
# else:
#   print("x is greater than y")

# conditional statements let you use "a if C else b" a single conditional statement
result = "x is less than y" if (x <y) else "x is greater or equal to y"
print(result) 